# Change Log

##[1.2.1] 2018-09-25
### Bugfixing
- `bootstrap.min.css` - `v3.3.5` changed to latest version `v3.3.7`

## [1.2.0] 2018-08-20
### Bugfixing, Updates
- Plugins updated to the latest versions
- Old mobile navbar with javascript were changed to only css mobile navbar for better performances
- `SASS` folder renamed to `SCSS`
- Other bug fixing

## [1.1.1] 2017-02-08
### MIT License
- Switched to MIT license

## [1.1.0] 2016-09-30
### New Page
- Added Upgrade to PRO page for those who want to upsell inside the dashboard

## [1.0.0] 2016-03-29
### Original Release
